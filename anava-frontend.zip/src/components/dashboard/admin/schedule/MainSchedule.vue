<template>
    <div>
        <!-- Penyisihan -->
        <b-card no-body class="overflow-hidden shadow mt-4">
            <b-row no-gutters>
                <b-col md="4">
                    <b-card-text>
                        <p class="mt-4">Senin</p>
                        <p style="font-size: 70px;margin-top:-25px;">12</p>
                        <p style="margin-top:-20px;">November</p>
                    </b-card-text>
                </b-col>
                <b-col md="8 text-left">
                    <b-card-body title="Penyisihan">
                    <b-card-text>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quis id saepe odio temporibus dolores, nisi eius? Officia similique maiores molestiae
                    </b-card-text>
                    </b-card-body>
                </b-col>
            </b-row>
        </b-card>
        <!-- Semifinal -->
        <b-card no-body class="overflow-hidden shadow mt-4">
            <b-row no-gutters>
                <b-col md="4">
                    <b-card-text>
                        <p class="mt-4">Senin</p>
                        <p style="font-size: 70px;margin-top:-25px;">22</p>
                        <p style="margin-top:-20px;">November</p>
                    </b-card-text>
                </b-col>
                <b-col md="8 text-left">
                    <b-card-body title="Semi Final">
                    <b-card-text>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quis id saepe odio temporibus dolores, nisi eius? Officia similique maiores molestiae
                    </b-card-text>
                    </b-card-body>
                </b-col>
            </b-row>
        </b-card>
        <!-- Final -->
        <b-card no-body class="overflow-hidden shadow mt-4">
            <b-row no-gutters>
                <b-col md="4">
                    <b-card-text>
                        <p class="mt-4">Senin</p>
                        <p style="font-size: 70px;margin-top:-25px;">30</p>
                        <p style="margin-top:-20px;">November</p>
                    </b-card-text>
                </b-col>
                <b-col md="8 text-left">
                    <b-card-body title="Final">
                    <b-card-text>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quis id saepe odio temporibus dolores, nisi eius? Officia similique maiores molestiae
                    </b-card-text>
                    </b-card-body>
                </b-col>
            </b-row>
        </b-card>
    </div>
</template>
<script>
export default {
    name: 'MainSchedule'
}
</script>