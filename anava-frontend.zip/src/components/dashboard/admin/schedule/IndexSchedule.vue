<template>
    <b-container>
        <h3 class="text-left">Jadwal</h3><hr/>
        <router-view/>
    </b-container>
</template>
