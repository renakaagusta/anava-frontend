<template>
    <div>
        <h3 class="text-left ml-4">Dokumen</h3><hr/>
        <router-view/>
    </div>
</template>
