<template>
    <b-container>
        <h3 class="text-left">Pembayaran</h3><hr/>
        <router-view/>
    </b-container>
</template>